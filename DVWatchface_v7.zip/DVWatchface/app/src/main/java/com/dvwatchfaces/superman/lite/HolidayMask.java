package com.dvwatchfaces.superman.lite;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.provider.CalendarContract;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.TemporalAdjusters;
import java.util.Locale;

/**
 * Маска недели (Пн=0 ... Вс=6):
 *  биты 0..6  — праздничные/выходные дни (жёлтые на циферблате),
 *  биты 7..13 — дни рождения (зелёные).
 * Читает системный календарь и календарь Wear (WearableCalendarContract).
 */
public final class HolidayMask {

    public static final class Result {
        public int mask;
        public int holidays;
        public int birthdays;
        public int contactBd;   // всего дней рождения в контактах
        public int total;       // всего событий в окне недели
        public boolean permission;
        public String details = "";
    }

    private static final String[] HOLIDAY_WORDS = {
            "праздник", "выходн", "нерабоч", "holiday", "перенос", "каникул", "отпуск"};
    private static final String[] BIRTHDAY_WORDS = {
            "рожден", "birthday", "д.р.", "днюха", "юбилей"};

    private HolidayMask() {}

    public static Result compute(Context ctx) {
        Result r = new Result();
        r.permission = ctx.checkSelfPermission(Manifest.permission.READ_CALENDAR)
                == PackageManager.PERMISSION_GRANTED;
        if (!r.permission) return r;

        ZoneId zone = ZoneId.systemDefault();
        LocalDate mon = LocalDate.now(zone).with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        long monEpochDay = mon.toEpochDay();
        long startMs = mon.minusDays(1).atStartOfDay(zone).toInstant().toEpochMilli();
        long endMs = mon.plusDays(8).atStartOfDay(zone).toInstant().toEpochMilli();

        // 1) системный календарь
        Uri.Builder b = CalendarContract.Instances.CONTENT_URI.buildUpon();
        ContentUris.appendId(b, startMs);
        ContentUris.appendId(b, endMs);
        scan(ctx, r, b.build(),
                new String[]{"begin", "end", "title", "allDay"}, monEpochDay, zone, "sys");

        // 2) календарь Wear (Google Calendar на часах)
        String W = "content://com.google.android.wearable.provider.calendar/instances/";
        scan(ctx, r, Uri.parse(W + "when/" + startMs + "/" + endMs),
                new String[]{"begin", "end", "title", "allDay"}, monEpochDay, zone, "wear");
        long jd0 = monEpochDay - 1 + 2440588L, jd1 = monEpochDay + 8 + 2440588L;
        scan(ctx, r, Uri.parse(W + "whenbyday/" + jd0 + "/" + jd1),
                new String[]{"begin", "end", "title", "allDay"}, monEpochDay, zone, "wearday");
        contacts(ctx, r, mon);
        return r;
    }

    /** Дни рождения из контактов (ContactsContract, тип события «день рождения»). */
    private static void contacts(Context ctx, Result r, LocalDate mon) {
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            r.details += "нет доступа к контактам\n";
            return;
        }
        java.util.regex.Pattern p = java.util.regex.Pattern.compile(
                "(?:(\\d{4})-)?-?(\\d{1,2})-(\\d{1,2})");
        try (Cursor c = ctx.getContentResolver().query(
                android.provider.ContactsContract.Data.CONTENT_URI,
                new String[]{android.provider.ContactsContract.Data.DISPLAY_NAME,
                        android.provider.ContactsContract.CommonDataKinds.Event.START_DATE},
                android.provider.ContactsContract.Data.MIMETYPE + "=? AND "
                        + android.provider.ContactsContract.CommonDataKinds.Event.TYPE + "=?",
                new String[]{android.provider.ContactsContract.CommonDataKinds.Event.CONTENT_ITEM_TYPE,
                        String.valueOf(android.provider.ContactsContract.CommonDataKinds.Event.TYPE_BIRTHDAY)},
                null)) {
            if (c == null) return;
            while (c.moveToNext()) {
                r.contactBd++;
                String d = c.getString(1);
                if (d == null) continue;
                java.util.regex.Matcher m = p.matcher(d.trim());
                if (!m.matches()) continue;
                int mo = Integer.parseInt(m.group(2)), da = Integer.parseInt(m.group(3));
                for (int k = 0; k < 7; k++) {
                    LocalDate day = mon.plusDays(k);
                    if (day.getMonthValue() == mo && day.getDayOfMonth() == da) {
                        if ((r.mask & (1 << (k + 7))) == 0) {
                            r.mask |= 1 << (k + 7);
                            r.birthdays++;
                            r.details += "ДР " + dow(k) + ": " + c.getString(0) + "\n";
                        }
                    }
                }
            }
        } catch (Exception e) {
            r.details += "contacts: " + e.getClass().getSimpleName() + "\n";
        }
    }

    private static void scan(Context ctx, Result r, Uri uri, String[] proj,
                             long monEpochDay, ZoneId zone, String tag) {
        try (Cursor c = ctx.getContentResolver().query(uri, proj, null, null, null)) {
            if (c == null) return;
            while (c.moveToNext()) {
                String rawTitle = c.getString(2);
                String title = rawTitle == null ? "" : rawTitle.toLowerCase(Locale.ROOT);
                boolean allDay = c.getInt(3) == 1;
                long begin = c.getLong(0), end = c.getLong(1);
                r.total++;
                boolean bd = hasAny(title, BIRTHDAY_WORDS);
                boolean hol = !bd && allDay && hasAny(title, HOLIDAY_WORDS);
                if (!bd && !hol) continue;
                long first, last;
                if (allDay) { // сутки по UTC
                    first = Math.floorDiv(begin, 86400000L);
                    last = Math.floorDiv(end - 1, 86400000L);
                } else {      // по местному времени
                    first = java.time.Instant.ofEpochMilli(begin).atZone(zone).toLocalDate().toEpochDay();
                    last = java.time.Instant.ofEpochMilli(Math.max(begin, end - 1))
                            .atZone(zone).toLocalDate().toEpochDay();
                }
                for (long d = first; d <= last; d++) {
                    long k = d - monEpochDay;
                    if (k < 0 || k > 6) continue;
                    int bit = (int) k + (bd ? 7 : 0);
                    if ((r.mask & (1 << bit)) == 0) {
                        r.mask |= 1 << bit;
                        if (bd) r.birthdays++; else r.holidays++;
                        r.details += (bd ? "ДР " : "Вых ") + dow((int) k) + ": " + rawTitle + "\n";
                    }
                }
            }
        } catch (Exception e) {
            r.details += tag + ": " + e.getClass().getSimpleName() + "\n";
        }
    }

    /** Подробная диагностика: сколько строк и какие названия отдаёт каждый источник за ±45 дней. */
    public static String diag(Context ctx) {
        StringBuilder sb = new StringBuilder();
        long now = System.currentTimeMillis();
        long a = now - 45L * 86400000L, b = now + 45L * 86400000L;
        long ja = Math.floorDiv(a, 86400000L) + 2440588L, jb = Math.floorDiv(b, 86400000L) + 2440588L;
        String W = "content://com.google.android.wearable.provider.calendar/";
        String[][] src = {
                {"sys", CalendarContract.Instances.CONTENT_URI + "/" + a + "/" + b},
                {"wear", W + "instances/when/" + a + "/" + b},
                {"wday", W + "instances/whenbyday/" + ja + "/" + jb},
                {"wevt", W + "events"},
        };
        for (String[] s : src) {
            try (Cursor c = ctx.getContentResolver().query(Uri.parse(s[1]), null, null, null, null)) {
                if (c == null) { sb.append(s[0]).append(": null\n"); continue; }
                sb.append(s[0]).append(": ").append(c.getCount()).append(" стр\n");
                int ti = c.getColumnIndex("title"), ad = c.getColumnIndex("allDay");
                int n = 0;
                while (c.moveToNext() && n++ < 8) {
                    sb.append("  ").append(ti >= 0 ? c.getString(ti) : "?")
                      .append(ad >= 0 ? " [" + c.getInt(ad) + "]" : "").append('\n');
                }
                if (c.getCount() > 0 && c.moveToFirst() == false) { }
            } catch (Exception e) {
                sb.append(s[0]).append(": ").append(e.getClass().getSimpleName())
                  .append(' ').append(String.valueOf(e.getMessage()).replace('\n', ' ')).append('\n');
            }
        }
        return sb.toString();
    }

    static String dow(int k) {
        return new String[]{"Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"}[k];
    }

    private static boolean hasAny(String s, String[] words) {
        for (String w : words) if (s.contains(w)) return true;
        return false;
    }
}
