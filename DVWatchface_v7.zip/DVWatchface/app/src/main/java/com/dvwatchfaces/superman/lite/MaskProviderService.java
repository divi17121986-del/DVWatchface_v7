package com.dvwatchfaces.superman.lite;

import android.os.RemoteException;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.wear.watchface.complications.data.ComplicationData;
import androidx.wear.watchface.complications.data.ComplicationType;
import androidx.wear.watchface.complications.data.PlainComplicationText;
import androidx.wear.watchface.complications.data.RangedValueComplicationData;
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceService;
import androidx.wear.watchface.complications.datasource.ComplicationRequest;

/**
 * Отдаёт маску праздничных дней текущей недели (Пн=бит 0 ... Вс=бит 6) в виде RANGED_VALUE 0..16383.
 */
public class MaskProviderService extends ComplicationDataSourceService {

    @Nullable
    @Override
    public ComplicationData getPreviewData(@NonNull ComplicationType type) {
        return build(5);
    }

    @Override
    public void onComplicationRequest(@NonNull ComplicationRequest request,
                                      @NonNull ComplicationRequestListener listener) {
        final android.content.Context ctx = getApplicationContext();
        new Thread(() -> {
            int mask = 0;
            try {
                mask = HolidayMask.compute(ctx).mask;
            } catch (Throwable ignored) {
            }
            try {
                listener.onComplicationData(build(mask));
            } catch (RemoteException ignored) {
            }
        }).start();
    }

    private static ComplicationData build(int mask) {
        return new RangedValueComplicationData.Builder(
                (float) mask, 0f, 16383f,
                new PlainComplicationText.Builder("Маска праздников").build())
                .setText(new PlainComplicationText.Builder(String.valueOf(mask)).build())
                .build();
    }
}
